package aqms.service;

import aqms.domain.enums.UserRole;
import aqms.domain.model.UserAccount;
import aqms.repository.UserAccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

  private final UserAccountRepository users;
  private final PasswordEncoder encoder;
  private final JwtService jwt;

  /** Registers a patient and returns a JWT. */
  public String registerPatient(String username, String rawPassword, String ignored) {
    if (users.existsByUsername(username)) {
      throw new IllegalStateException("Username taken");
    }
    var u = new UserAccount(username, encoder.encode(rawPassword), UserRole.PATIENT);
    users.save(u);
    return jwt.issueToken(u.getUsername(), u.getRole().name());
  }

  /** Validates credentials and returns a JWT. */
  public String login(String username, String rawPassword) {
    var u = users.findByUsername(username)
        .orElseThrow(() -> new IllegalStateException("Bad credentials"));
    if (!encoder.matches(rawPassword, u.getPasswordHash())) {
      throw new IllegalStateException("Bad credentials");
    }
    return jwt.issueToken(u.getUsername(), u.getRole().name());
  }
}
