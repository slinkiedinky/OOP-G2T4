package aqms.domain.event;

public record QueueAdvancedEvent(Long clinicId) {}