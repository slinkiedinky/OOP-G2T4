package aqms.domain.event;

public record AppointmentCancelledEvent(Long slotId) {}