package aqms.domain.enums;

public enum QueuePriority { NORMAL, EXPRESS, EMERGENCY }
