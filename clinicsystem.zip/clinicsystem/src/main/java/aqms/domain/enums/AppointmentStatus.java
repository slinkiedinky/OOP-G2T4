package aqms.domain.enums;

public enum AppointmentStatus { AVAILABLE, BOOKED, CHECKED_IN, CANCELLED, COMPLETED, NO_SHOW }