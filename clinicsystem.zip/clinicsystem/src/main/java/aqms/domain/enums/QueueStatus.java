package aqms.domain.enums;

public enum QueueStatus { WAITING, CALLED, SKIPPED, COMPLETED }