package aqms.domain.enums;

public enum UserRole { PATIENT, STAFF, ADMIN }